# RedRelay — LifeLine Hackathon (Improved)

A React + Express + SQLite blood-request coordination prototype. It demonstrates ABO/Rh red-cell compatibility, locality-based matching, SOS requests, donor pledges, request lifecycle tracking, and a 90-day donor recovery lock.

> **Important:** This is an academic demonstration, not a medical service. Compatibility is a simplified red-cell model and all transfusions must be determined by qualified medical professionals and cross-matching. SMS is simulated; no real messages are sent.

## Requirements
- Node.js 22 or newer (the `better-sqlite3` version in this project requires a modern Node runtime)
- npm

## Setup
```bash
npm run setup
cp server/.env.example server/.env
# Set a unique JWT_SECRET in server/.env before deployment.
npm run dev
```
Client: http://localhost:5173 · API: http://localhost:4000

Production build:
```bash
npm run build
npm start
```

Tests:
```bash
npm test
```

## Demo
The database seeds sample donors and requests on first launch. Register/login endpoints are available:
- `POST /api/auth/register` — `{ "name", "email", "password", "role" }`
- `POST /api/auth/login` — `{ "email", "password" }`
- `GET /api/auth/me` — requires `Authorization: Bearer <token>`

The existing UI still includes a clearly labelled donor demo-profile selector for classroom demonstration. It is not production authentication.

## Main API
- `GET /api/meta`
- `GET /api/requests` (legacy array response)
- `GET /api/requests?paginated=1&page=1&limit=20` (paged response)
- `POST /api/requests`
- `GET /api/requests/:id`
- `GET /api/requests/:id/donors?radius=15`
- `POST /api/requests/:id/respond`
- `POST /api/requests/:id/close`
- `POST /api/requests/:id/broadcast` (simulation only)
- `GET/POST /api/donors`
- `GET /api/donors/:id/matches`
- `PATCH /api/donors/:id/availability`

## Engineering improvements included
1. Helmet security headers, bounded JSON body size, request logging, no-store API responses, and centralized error handling.
2. Bcrypt password hashing and JWT register/login/profile endpoints; production startup requires a configured JWT secret.
3. Server-side validation and normalized user input for core request/donor/auth fields.
4. SQLite foreign-key enforcement, WAL mode, busy timeout, indexes, and transactional pledge capacity checks.
5. Paginated request API while retaining the existing array response for compatibility.
6. Visible 90-day recovery countdown in the donor registry and donor profile.
7. Existing compatibility and API tests retained and corrected for the actual donor-list response.

## Configuration
Create `server/.env` from `.env.example`. Never commit real secrets. The built-in development JWT key is for local classroom use only; production requires a unique secret. Set `CLIENT_ORIGIN` to a comma-separated allowlist of frontend origins if deploying.

## Known limitations / honest scope
- Donor demo-profile selection is not real identity verification. Protect donor write operations with authenticated ownership checks before public deployment.
- The request owner token is a demo capability token; a production system should bind request ownership to an authenticated user and rotate/revoke sessions.
- Doctor contact is collected but not verified.
- SMS dispatch is simulated only.
- Locality-center distances and ETA are estimates, not live road routing.
- Add a managed database, backups, monitoring, rate limiting, and external security review before any real-world deployment.
