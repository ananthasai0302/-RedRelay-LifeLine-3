import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, tokens, useMeta } from '../api.js';

export default function NewRequest() {
  const { localities, groups } = useMeta();
  const nav = useNavigate();
  const [f, setF] = useState({ patient: '', hospital: '', locality: '', bloodGroup: '', units: 1, hoursLeft: 4, doctorContact: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setErr('');
    try {
      const { id, token } = await api.post('/requests', f);
      tokens.set(id, token);
      nav(`/request/${id}`);
    } catch (x) { setErr(x.message); setBusy(false); }
  }

  return (
    <form onSubmit={submit} className="mx-auto max-w-xl space-y-4 rounded-xl border border-ink/10 bg-white p-5">
      <h1 className="text-2xl font-extrabold">Request blood</h1>
      <p className="text-sm text-ink/70">The verifying doctor's number stays private. It is never shown to donors or on the public feed. Requests expire after 24 hours.</p>
      <label className="block">Patient name
        <input className="field" value={f.patient} onChange={set('patient')} required />
      </label>
      <label className="block">Hospital
        <input className="field" placeholder="Apollo Hospital, Jubilee Hills" value={f.hospital} onChange={set('hospital')} required />
      </label>
      <label className="block">Hospital locality
        <select className="field" value={f.locality} onChange={set('locality')} required>
          <option value="">Choose…</option>
          {localities.map((l) => <option key={l}>{l}</option>)}
        </select>
      </label>
      <div className="grid grid-cols-3 gap-3">
        <label className="block">Blood group
          <select className="field" value={f.bloodGroup} onChange={set('bloodGroup')} required>
            <option value="">…</option>
            {groups.map((g) => <option key={g}>{g}</option>)}
          </select>
        </label>
        <label className="block">Units
          <input className="field" type="number" min="1" max="10" value={f.units} onChange={set('units')} required />
        </label>
        <label className="block">Needed within (hours)
          <input className="field" type="number" min="0.5" max="24" step="0.5" value={f.hoursLeft} onChange={set('hoursLeft')} required />
        </label>
      </div>
      <label className="block">Verifying doctor's phone
        <input className="field" inputMode="numeric" placeholder="10 digits" value={f.doctorContact} onChange={set('doctorContact')} required />
      </label>
      {err && <p role="alert" className="rounded-lg bg-blood-tint p-3 text-blood-dark">{err}</p>}
      <button className="btn-red w-full" disabled={busy}>{busy ? 'Broadcasting…' : 'Broadcast SOS'}</button>
    </form>
  );
}
