﻿import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api, auth, usePoll } from '../api.js';
import RequestCard from '../components/RequestCard.jsx';

export default function Feed() {
  const [pageData, setPageData] = useState(null);
  const [page, setPage] = useState(1);
  const [user, setUser] = useState(() => auth.getUser());
  const [err, setErr] = useState('');

  usePoll(
    () => api.get(`/requests?page=${page}&limit=6&paginated=1`).then((d) => { setPageData(d); setErr(''); }).catch((e) => setErr(e.message)),
    5000,
    [page]
  );

  async function handleDemoLogin() {
    try {
      const res = await api.post('/auth/login', { email: 'ravi@redrelay.org', password: 'RedRelay@123' });
      auth.setSession(res.token, res.user);
      setUser(res.user);
    } catch (e) { setErr(e.message); }
  }

  function handleLogout() {
    auth.clear();
    setUser(null);
  }

  const list = pageData?.items || null;
  const active = (list || []).filter((r) => r.status !== 'closed');
  const closed = (list || []).filter((r) => r.status === 'closed');

  return (
    <>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">{active.length} families need blood right now</h1>
          <p className="mt-1 text-ink/70">Sorted by deadline. Counters refresh every few seconds.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {user ? (
            <button onClick={handleLogout} className="rounded-lg border border-ink/20 bg-white px-3 py-2 text-sm font-semibold">
              Signed in: {user.name} (Sign out)
            </button>
          ) : (
            <button onClick={handleDemoLogin} className="rounded-lg border border-ink/20 bg-white px-3 py-2 text-sm font-semibold">
              Coordinator JWT Sign-In
            </button>
          )}
          <Link to="/sos" className="btn-red">Post an SOS</Link>
        </div>
      </div>
      {err && <p className="rounded-lg bg-blood-tint p-3 text-blood-dark">Could not reach the server: {err}.</p>}
      {!list && !err && <p>Loading requests…</p>}
      <div className="grid gap-3 md:grid-cols-2">{active.map((r) => <RequestCard key={r.id} r={r} />)}</div>
      {list && active.length === 0 && <p className="rounded-lg bg-white p-4">No open requests on this page.</p>}
      {pageData && pageData.totalPages > 1 && (
        <div className="mt-5 flex items-center justify-between rounded-lg bg-white p-3 text-sm">
          <span>Page <strong>{pageData.page}</strong> of <strong>{pageData.totalPages}</strong> ({pageData.total} total requests)</span>
          <div className="flex gap-2">
            <button disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))} className="rounded border px-3 py-1 disabled:opacity-40">Previous</button>
            <button disabled={page >= pageData.totalPages} onClick={() => setPage((p) => p + 1)} className="rounded border px-3 py-1 disabled:opacity-40">Next</button>
          </div>
        </div>
      )}
      {closed.length > 0 && (
        <>
          <h2 className="mb-3 mt-8 text-lg font-bold text-ink/70">Recently closed</h2>
          <div className="grid gap-3 md:grid-cols-2">{closed.map((r) => <RequestCard key={r.id} r={r} />)}</div>
        </>
      )}
    </>
  );
}
