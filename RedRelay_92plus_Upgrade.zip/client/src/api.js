﻿import { useEffect, useRef, useState } from 'react';

export const auth = {
  getToken: () => localStorage.getItem('rr_jwt') || '',
  getUser: () => JSON.parse(localStorage.getItem('rr_user') || 'null'),
  setSession: (token, user) => {
    localStorage.setItem('rr_jwt', token);
    localStorage.setItem('rr_user', JSON.stringify(user));
  },
  clear: () => {
    localStorage.removeItem('rr_jwt');
    localStorage.removeItem('rr_user');
  },
};

async function call(url, method = 'GET', body) {
  const jwt = auth.getToken();
  const headers = { 'Content-Type': 'application/json' };
  if (jwt) headers.Authorization = `Bearer ${jwt}`;
  const res = await fetch('/api' + url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Try again.');
  return data;
}

export const api = {
  get: (u) => call(u),
  post: (u, b) => call(u, 'POST', b || {}),
  patch: (u, b) => call(u, 'PATCH', b),
};

export const tokens = {
  all: () => JSON.parse(localStorage.getItem('rr_tokens') || '{}'),
  get: (id) => tokens.all()[id],
  set: (id, t) => localStorage.setItem('rr_tokens', JSON.stringify({ ...tokens.all(), [id]: t })),
};

export function usePoll(fn, ms, deps = []) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    const run = () => ref.current();
    run();
    const t = setInterval(run, ms);
    return () => clearInterval(t);
  }, deps);
}

let metaPromise;
export function useMeta() {
  const [meta, setMeta] = useState({ localities: [], groups: [] });
  useEffect(() => {
    metaPromise = metaPromise || api.get('/meta');
    metaPromise.then(setMeta).catch(() => {});
  }, []);
  return meta;
}

export function timeLeft(ts) {
  const ms = ts - Date.now();
  if (ms <= 0) return 'deadline passed';
  const m = Math.round(ms / 60000);
  if (m < 60) return `${m} min left`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m left`;
}
