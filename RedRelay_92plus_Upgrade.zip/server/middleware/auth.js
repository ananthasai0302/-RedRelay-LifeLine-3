import jwt from 'jsonwebtoken';

const developmentSecret = 'redrelay-local-development-only-change-before-deployment';
const JWT_SECRET = process.env.JWT_SECRET || (process.env.NODE_ENV === 'production' ? '' : developmentSecret);
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  throw new Error('JWT_SECRET must be configured with at least 32 characters before production startup');
}

export function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '8h', issuer: 'redrelay', audience: 'redrelay-client' });
}
export function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET, { issuer: 'redrelay', audience: 'redrelay-client' });
}
export function optionalAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  if (header.startsWith('Bearer ')) {
    try { req.user = verifyToken(header.slice(7)); } catch { req.user = null; }
  }
  next();
}
export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return res.status(401).json({ error: 'Authentication required', code: 'AUTH_MISSING_TOKEN', status: 401 });
  try { req.user = verifyToken(header.slice(7)); next(); }
  catch { return res.status(401).json({ error: 'Invalid or expired authentication token', code: 'AUTH_INVALID_TOKEN', status: 401 }); }
}
