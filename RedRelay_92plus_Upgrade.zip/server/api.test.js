﻿import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import supertestPkg from 'supertest';

const request = supertestPkg.default || supertestPkg;

process.env.NODE_ENV = 'test';
const tmpDb = path.join(os.tmpdir(), `redrelay-test-${Date.now()}.db`);
process.env.DB_PATH = tmpDb;

const { app } = await import('./index.js');
const { db } = await import('./db.js');
const server = http.createServer(app);
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));

test.after(() => {
  server.close();
  db.close();
  for (const suffix of ['', '-wal', '-shm']) {
    if (fs.existsSync(tmpDb + suffix)) fs.unlinkSync(tmpDb + suffix);
  }
});

let authToken = '';
let createdRequestId = 0;
let requestOwnerToken = '';

test('POST /api/auth/register & /api/auth/login issue valid JWT tokens', async () => {
  const reg = await request(server)
    .post('/api/auth/register')
    .send({ name: 'Test Coordinator', email: 'coord@redrelay.org', password: 'Password123', role: 'member' });
  assert.equal(reg.status, 201);
  assert.ok(reg.body.token);

  const login = await request(server)
    .post('/api/auth/login')
    .send({ email: 'coord@redrelay.org', password: 'Password123' });
  assert.equal(login.status, 200);
  assert.ok(login.body.token);
  authToken = login.body.token;

  const me = await request(server)
    .get('/api/auth/me')
    .set('Authorization', `Bearer ${authToken}`);
  assert.equal(me.status, 200);
  assert.equal(me.body.user.email, 'coord@redrelay.org');
});

test('POST /api/requests validates inputs and creates an SOS request', async () => {
  const bad = await request(server)
    .post('/api/requests')
    .send({ patient: '', hospital: 'Apollo', locality: 'InvalidPlace', bloodGroup: 'Z+', units: 20, hoursLeft: 4 });
  assert.equal(bad.status, 400);
  assert.ok(bad.body.code);

  const ok = await request(server)
    .post('/api/requests')
    .set('Authorization', `Bearer ${authToken}`)
    .send({
      patient: 'Anant Sharma',
      hospital: 'Apollo Hospital, Banjara Hills',
      locality: 'Banjara Hills',
      bloodGroup: 'B+',
      units: 1,
      hoursLeft: 4,
      doctorContact: '9876543210',
    });
  assert.equal(ok.status, 201);
  assert.ok(ok.body.id);
  createdRequestId = ok.body.id;
  requestOwnerToken = ok.body.token;
});

test('GET /api/requests supports pagination metadata and limits', async () => {
  const res = await request(server).get('/api/requests?page=1&limit=3&paginated=1');
  assert.equal(res.status, 200);
  assert.equal(res.body.items.length, 3);
  assert.equal(res.body.page, 1);
  assert.ok(res.body.total >= 6);
  assert.equal(res.headers['x-page'], '1');
});

test('Full donor pledge, closure, and 90-day cooldown enforcement', async () => {
  const donorsRes = await request(server).get(`/api/requests/${createdRequestId}/donors?radius=50`);
  assert.equal(donorsRes.status, 200);
  assert.ok(donorsRes.body.length > 0);
  const donorId = donorsRes.body[0].id;

  const pledge = await request(server)
    .post(`/api/requests/${createdRequestId}/respond`)
    .send({ donorId });
  assert.equal(pledge.status, 201);
  assert.equal(pledge.body.status, 'fulfilled');

  const unauthClose = await request(server)
    .post(`/api/requests/${createdRequestId}/close`)
    .send({ token: 'wrong-token' });
  assert.equal(unauthClose.status, 403);

  const closeRes = await request(server)
    .post(`/api/requests/${createdRequestId}/close`)
    .set('Authorization', `Bearer ${authToken}`)
    .send({ token: requestOwnerToken });
  assert.equal(closeRes.status, 200);
  assert.equal(closeRes.body.status, 'closed');

  const allDonors = await request(server).get('/api/donors');
  const lockedDonor = allDonors.body.find((d) => d.id === donorId);
  assert.equal(lockedDonor.ready, false);
  assert.ok(lockedDonor.unlockAt > Date.now());
});
