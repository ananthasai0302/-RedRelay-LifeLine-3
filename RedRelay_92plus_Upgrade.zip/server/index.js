﻿import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import bcrypt from 'bcryptjs';
import { signToken, requireAuth } from './middleware/auth.js';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db, LOCALITIES } from './db.js';
import { GROUPS, canDonate, donorsFor } from './compat.js';

const HOUR = 36e5, DAY = 24 * HOUR, COOLDOWN = 90 * DAY;
const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN ? process.env.CLIENT_ORIGIN.split(',') : true }));
app.use(express.json({ limit: '32kb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

const fail = (res, code, error, detail = {}) => res.status(code).json({ error, code: `HTTP_${code}`, ...detail });
const cleanText = (value, max = 120) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const validEmail = (value) => /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(value);
const initials = (name) => name.split(/\s+/).filter(Boolean).map((p) => p[0].toUpperCase()).join('.') + '.';

function km(a, b) {
  const [la1, lo1] = LOCALITIES[a], [la2, lo2] = LOCALITIES[b];
  const rad = (x) => (x * Math.PI) / 180;
  const h = Math.sin(rad(la2 - la1) / 2) ** 2 + Math.cos(rad(la1)) * Math.cos(rad(la2)) * Math.sin(rad(lo2 - lo1) / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
}
// city traffic is slow: ~22 km/h plus a few minutes to get moving
const etaMin = (d) => Math.round((d / 22) * 60) + 4;

const isReady = (d) => d.available === 1 && (!d.last_donation || Date.now() - d.last_donation >= COOLDOWN);
const unlockAt = (d) => (d.last_donation && Date.now() - d.last_donation < COOLDOWN ? d.last_donation + COOLDOWN : null);

const committedFor = (id) =>
  db.prepare('SELECT COALESCE(SUM(units),0) n FROM responses WHERE request_id = ?').get(id).n;

// Recomputes the stepper stage. Runs on every read so ghost requests die on their own.
function refresh(id) {
  let r = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
  if (!r || r.status === 'closed') return r;
  if (Date.now() > r.expires_at) {
    db.prepare("UPDATE requests SET status='closed', closed_reason='expired' WHERE id=?").run(id);
    return db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
  }
  const c = committedFor(id);
  const status = c >= r.units ? 'fulfilled' : c > 0 ? 'responded' : 'open';
  if (status !== r.status) db.prepare('UPDATE requests SET status=? WHERE id=?').run(status, id);
  return { ...r, status };
}

const publicRequest = (r) => ({
  id: r.id,
  patient: initials(r.patient),
  hospital: r.hospital,
  locality: r.locality,
  bloodGroup: r.blood_group,
  units: r.units,
  committed: committedFor(r.id),
  status: r.status,
  closedReason: r.closed_reason,
  deadlineAt: r.deadline_at,
  expiresAt: r.expires_at,
  createdAt: r.created_at,
  compatibleGroups: donorsFor(r.blood_group),
});

function eligibleDonors(r, radius) {
  const groups = donorsFor(r.blood_group);
  return db.prepare(`SELECT * FROM donors WHERE blood_group IN (${groups.map(() => '?').join(',')})`).all(...groups)
    .filter(isReady)
    .map((d) => ({ d, dist: km(d.locality, r.locality) }))
    .filter((x) => x.dist <= radius)
    .sort((a, b) => a.dist - b.dist)
    .map(({ d, dist }) => ({
      id: d.id, initials: initials(d.name), bloodGroup: d.blood_group, locality: d.locality,
      distanceKm: Math.round(dist * 10) / 10, etaMin: etaMin(dist),
    }));
}

// Authentication endpoints use bcrypt password hashes and short-lived signed JWTs.
app.post('/api/auth/register', (req, res) => {
  const name = cleanText(req.body?.name, 80);
  const email = cleanText(req.body?.email, 160).toLowerCase();
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const role = ['member', 'donor'].includes(req.body?.role) ? req.body.role : 'member';
  if (name.length < 2 || !validEmail(email) || password.length < 10 || password.length > 72)
    return fail(res, 400, 'Provide a name, valid email, and password of 10–72 characters');
  try {
    const hash = bcrypt.hashSync(password, 12);
    const result = db.prepare('INSERT INTO users (name,email,password_hash,role,created_at) VALUES (?,?,?,?,?)')
      .run(name, email, hash, role, Date.now());
    const user = { id: Number(result.lastInsertRowid), name, email, role };
    return res.status(201).json({ user, token: signToken(user) });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') return fail(res, 409, 'An account with this email already exists');
    throw error;
  }
});
app.post('/api/auth/login', (req, res) => {
  const email = cleanText(req.body?.email, 160).toLowerCase();
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const row = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!row || !bcrypt.compareSync(password, row.password_hash)) return fail(res, 401, 'Email or password is incorrect');
  const user = { id: row.id, name: row.name, email: row.email, role: row.role };
  res.json({ user, token: signToken(user) });
});
app.get('/api/auth/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(req.user.id);
  if (!user) return fail(res, 401, 'Account no longer exists');
  res.json({ user });
});

app.get('/api/meta', (_req, res) => res.json({ localities: Object.keys(LOCALITIES), groups: GROUPS }));

app.get('/api/requests', (req, res) => {
  const all = db.prepare('SELECT id FROM requests ORDER BY created_at DESC LIMIT 500').all().map((x) => publicRequest(refresh(x.id)));
  const ordered = [...all.filter((r) => r.status !== 'closed').sort((a, b) => a.deadlineAt - b.deadlineAt),
    ...all.filter((r) => r.status === 'closed').slice(0, 10)];
  if (req.query.paginated === '1') {
    const page = Math.max(1, Math.floor(Number(req.query.page) || 1));
    const limit = Math.min(50, Math.max(1, Math.floor(Number(req.query.limit) || 20)));
    res.setHeader('X-Page', String(page));
    return res.json({ items: ordered.slice((page - 1) * limit, page * limit), page, limit, total: ordered.length,
      pages: Math.ceil(ordered.length / limit) });
  }
  res.json(ordered.slice(0, 60));
});

app.get('/api/requests/:id', (req, res) => {
  const r = refresh(Number(req.params.id));
  if (!r) return fail(res, 404, 'No such request');
  const responses = db.prepare(`SELECT s.units, s.state, s.created_at, d.name, d.locality, d.blood_group
    FROM responses s JOIN donors d ON d.id = s.donor_id WHERE s.request_id = ? ORDER BY s.created_at`).all(r.id)
    .map((x) => ({ initials: initials(x.name), locality: x.locality, bloodGroup: x.blood_group, units: x.units, state: x.state, at: x.created_at }));
  res.json({ ...publicRequest(r), responses });
});

app.post('/api/requests', (req, res) => {
  const { patient, hospital, locality, bloodGroup, units, hoursLeft, doctorContact } = req.body || {};
  const u = Number(units), h = Number(hoursLeft);
  if (cleanText(patient, 100).length < 2 || cleanText(hospital, 140).length < 2) return fail(res, 400, 'Patient name and hospital are required');
  if (!LOCALITIES[locality]) return fail(res, 400, 'Pick a locality from the list');
  if (!GROUPS.includes(bloodGroup)) return fail(res, 400, 'Pick a valid blood group');
  if (!Number.isInteger(u) || u < 1 || u > 10) return fail(res, 400, 'Units must be between 1 and 10');
  if (!(h >= 0.5 && h <= 24)) return fail(res, 400, 'Deadline must be between 30 minutes and 24 hours');
  if (!/^\d{10}$/.test(String(doctorContact || '').replace(/\s/g, ''))) return fail(res, 400, 'Enter the verifying doctor\'s 10 digit number');
  const now = Date.now();
  const token = crypto.randomBytes(12).toString('hex');
  const info = db.prepare(`INSERT INTO requests (patient, hospital, locality, blood_group, units, deadline_at, expires_at, doctor_contact, token, status, created_at)
    VALUES (?,?,?,?,?,?,?,?,?,'open',?)`)
    .run(cleanText(patient, 100), cleanText(hospital, 140), locality, bloodGroup, u, now + h * HOUR, now + DAY, String(doctorContact).replace(/\s/g, ''), token, now);
  res.status(201).json({ id: info.lastInsertRowid, token });
});

app.get('/api/requests/:id/donors', (req, res) => {
  const r = refresh(Number(req.params.id));
  if (!r) return fail(res, 404, 'No such request');
  const radius = Math.min(Math.max(Number(req.query.radius) || 15, 1), 100);
  res.json(eligibleDonors(r, radius));
});

// Pretend SMS dispatch. Nothing is sent; we just show what would go out.
app.post('/api/requests/:id/broadcast', (req, res) => {
  const r = refresh(Number(req.params.id));
  if (!r || r.status === 'closed') return fail(res, 400, 'This request is closed');
  const radius = Math.min(Math.max(Number(req.body?.radius) || 15, 1), 100);
  const list = eligibleDonors(r, radius);
  res.json(list.map((d) => ({
    to: `${d.initials} (${d.locality})`,
    text: `RedRelay SOS: ${r.units} unit(s) of ${r.blood_group} needed at ${r.hospital}, about ${d.distanceKm} km from you. Reply in the app with "I Can Donate".`,
  })));
});

app.post('/api/requests/:id/respond', (req, res) => {
  const r = refresh(Number(req.params.id));
  if (!r) return fail(res, 404, 'No such request');
  if (r.status === 'closed') return fail(res, 409, 'This request is already closed');
  const d = db.prepare('SELECT * FROM donors WHERE id = ?').get(Number(req.body?.donorId));
  if (!d) return fail(res, 404, 'Donor not found');
  if (!canDonate(d.blood_group, r.blood_group)) return fail(res, 403, `${d.blood_group} blood cannot be given to a ${r.blood_group} patient`);
  if (!isReady(d)) return fail(res, 403, 'You are marked unavailable or still in the 90 day recovery window');
  const remaining = r.units - committedFor(r.id);
  if (remaining <= 0) return fail(res, 409, 'All units are already covered');
  try {
    const pledge = db.transaction(() => {
      const current = db.prepare('SELECT status, units FROM requests WHERE id=?').get(r.id);
      const total = committedFor(r.id);
      if (!current || current.status === 'closed' || total >= current.units) throw new Error('REQUEST_FULL');
      db.prepare('INSERT INTO responses (request_id, donor_id, units, created_at) VALUES (?,?,1,?)')
        .run(r.id, d.id, Date.now());
    });
    pledge();
  } catch (error) {
    if (error.message === 'REQUEST_FULL') return fail(res, 409, 'All units are already covered');
    if (String(error.code || '').includes('CONSTRAINT')) return fail(res, 409, 'You already responded to this request');
    throw error;
  }
  const fresh = refresh(r.id);
  res.status(201).json(publicRequest(fresh));
});

// The family confirms the blood arrived. Starts the 90 day lock for every donor who gave.
app.post('/api/requests/:id/close', (req, res) => {
  const r = refresh(Number(req.params.id));
  if (!r) return fail(res, 404, 'No such request');
  if (req.body?.token !== r.token) return fail(res, 403, 'Only the family who posted this request can close it');
  if (r.status === 'closed') return fail(res, 409, 'Already closed');
  const tx = db.transaction(() => {
    const rows = db.prepare('SELECT donor_id FROM responses WHERE request_id = ?').all(r.id);
    rows.forEach((x) => db.prepare('UPDATE donors SET last_donation = ? WHERE id = ?').run(Date.now(), x.donor_id));
    db.prepare("UPDATE responses SET state='donated' WHERE request_id = ?").run(r.id);
    db.prepare("UPDATE requests SET status='closed', closed_reason='received' WHERE id = ?").run(r.id);
  });
  tx();
  res.json(publicRequest(refresh(r.id)));
});

const donorView = (d) => ({
  id: d.id, initials: initials(d.name), bloodGroup: d.blood_group, locality: d.locality,
  available: d.available === 1, ready: isReady(d), unlockAt: unlockAt(d),
  phone: 'Hidden. Contact goes through RedRelay.',
});

app.get('/api/donors', (_req, res) => {
  res.json(db.prepare('SELECT * FROM donors ORDER BY id DESC').all().map(donorView));
});

app.post('/api/donors', (req, res) => {
  const { name, bloodGroup, locality, phone } = req.body || {};
  if (cleanText(name, 80).length < 2) return fail(res, 400, 'Name must contain at least 2 characters');
  if (!GROUPS.includes(bloodGroup)) return fail(res, 400, 'Pick a valid blood group');
  if (!LOCALITIES[locality]) return fail(res, 400, 'Pick a locality from the list');
  if (!/^\d{10}$/.test(String(phone || '').replace(/\s/g, ''))) return fail(res, 400, 'Enter a 10 digit phone number');
  const info = db.prepare('INSERT INTO donors (name, blood_group, locality, phone) VALUES (?,?,?,?)')
    .run(cleanText(name, 80), bloodGroup, locality, String(phone).replace(/\s/g, ''));
  res.status(201).json(donorView(db.prepare('SELECT * FROM donors WHERE id = ?').get(info.lastInsertRowid)));
});

app.patch('/api/donors/:id/availability', (req, res) => {
  const d = db.prepare('SELECT * FROM donors WHERE id = ?').get(Number(req.params.id));
  if (!d) return fail(res, 404, 'Donor not found');
  db.prepare('UPDATE donors SET available = ? WHERE id = ?').run(req.body?.available ? 1 : 0, d.id);
  res.json(donorView(db.prepare('SELECT * FROM donors WHERE id = ?').get(d.id)));
});

// What a given donor can respond to right now, plus their donation history.
app.get('/api/donors/:id/matches', (req, res) => {
  const d = db.prepare('SELECT * FROM donors WHERE id = ?').get(Number(req.params.id));
  if (!d) return fail(res, 404, 'Donor not found');
  const open = db.prepare("SELECT id FROM requests WHERE status != 'closed'").all()
    .map((x) => refresh(x.id)).filter((r) => r.status !== 'closed' && canDonate(d.blood_group, r.blood_group))
    .map((r) => {
      const dist = km(d.locality, r.locality);
      const mine = db.prepare('SELECT 1 FROM responses WHERE request_id=? AND donor_id=?').get(r.id, d.id);
      return { ...publicRequest(r), distanceKm: Math.round(dist * 10) / 10, etaMin: etaMin(dist), alreadyResponded: !!mine };
    })
    .sort((a, b) => a.deadlineAt - b.deadlineAt);
  const history = db.prepare(`SELECT r.hospital, r.blood_group, s.created_at FROM responses s JOIN requests r ON r.id = s.request_id
    WHERE s.donor_id = ? AND s.state = 'donated' ORDER BY s.created_at DESC`).all(d.id)
    .map((h) => ({ hospital: h.hospital, bloodGroup: h.blood_group, at: h.created_at }));
  res.json({ donor: donorView(d), open, history });
});

// In production the built React app is served from here too.
const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '../client/dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use((err, _req, res, _next) => {
  console.error(JSON.stringify({ level: 'error', message: err.message, time: new Date().toISOString() }));
  if (err instanceof SyntaxError && 'body' in err) return fail(res, 400, 'Malformed JSON request body');
  return fail(res, 500, 'Internal server error');
});

export { app };
const PORT = process.env.PORT || 4000;
if (process.env.NODE_ENV !== "test") { app.listen(PORT, () => console.log(`RedRelay API on http://localhost:${PORT}`)); }

