# Upgrade notes mapped to the evaluation report

| Evaluation concern | Changes in this package |
|---|---|
| Missing 90-day rest timer UI | Donor registry/profile now show a live day-and-hour recovery countdown |
| Pledge race conditions | SQLite transaction checks remaining capacity and inserts pledge atomically |
| Authentication | Added register, login and current-user endpoints with bcrypt and JWT |
| Weak JWT fallback | Production startup refuses to run without a 32+ character JWT_SECRET |
| Input validation | Added bounded text normalization and stronger auth/request/donor checks |
| System reliability | Helmet, bounded JSON, request logging, centralized API errors, SQLite foreign keys and busy timeout |
| Missing pagination | Added optional page/limit API while preserving the old response format |
| Testing | Corrected API test donor selection; retained compatibility and API test suites |

## Validation status
Server JavaScript files passed `node --check`. Full automated tests and frontend production build were not completed because dependency installation did not finish in this environment. Run `npm run setup`, then `npm test` and `npm run build` locally before submission.

## Important
These engineering changes target the evaluator's comments; they do not guarantee a particular grade. Real production deployment still requires authenticated donor ownership on every donor write endpoint, verified medical workflows, external security review, and real notification infrastructure.
